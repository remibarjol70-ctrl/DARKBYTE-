import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { SUPABASE_URL, SUPABASE_ANON_KEY } from './supabase-config.js';
const supabase=createClient(SUPABASE_URL,SUPABASE_ANON_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
const $=id=>document.getElementById(id), msg=$('adminMessage'), app=$('adminApp');
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const dateLabel=v=>{if(!v)return 'Date non précisée';const d=new Date(v);return isNaN(d)?'Date non précisée':d.toLocaleString('fr-FR',{dateStyle:'medium',timeStyle:'short'});};
function message(t,type='ok'){msg.textContent=t;msg.className=`admin-message ${type}`;}
function selectStatus(id,value,options){return `<select data-status-for="${esc(id)}">${options.map(s=>`<option ${s===value?'selected':''}>${esc(s)}</option>`).join('')}</select>`;}
const appointmentStatuses=['En attente de confirmation','Confirmé','Refusé','Terminé'];
const quoteStatuses=['En attente','En cours de traitement','Devis envoyé','Accepté','Refusé','Terminé'];
async function loadAppointments(){
 const {data:rows,error}=await supabase.from('customer_appointments').select('id,user_id,appointment_date,service,status,created_at').order('created_at',{ascending:false}).limit(100);
 if(error)throw error; const ids=[...new Set((rows||[]).map(x=>x.user_id).filter(Boolean))];let profiles={};
 if(ids.length){const p=await supabase.from('profiles').select('id,full_name,phone').in('id',ids);if(p.error)throw p.error;for(const x of p.data||[])profiles[x.id]=x;}
 $('appointmentCount').textContent=`(${rows.length})`;
 $('appointmentsList').innerHTML=rows.length?rows.map(x=>{const p=profiles[x.user_id]||{};return `<article class="admin-card"><h3>${esc(x.service||'Rendez-vous')}</h3><div class="admin-meta"><strong>Client :</strong> ${esc(p.full_name||'Nom non renseigné')}<br><strong>Téléphone :</strong> ${esc(p.phone||'Non renseigné')}<br><strong>Date demandée :</strong> ${dateLabel(x.appointment_date)}<br><strong>Demande reçue :</strong> ${dateLabel(x.created_at)}<br><strong>Identifiant :</strong> ${esc(x.id)}</div><span class="admin-status">${esc(x.status||'En attente')}</span><div class="admin-actions">${selectStatus(x.id,x.status||appointmentStatuses[0],appointmentStatuses)}<button class="button primary" data-save-appointment="${esc(x.id)}" type="button">ENREGISTRER</button></div></article>`}).join(''):'<p class="admin-empty">Aucune demande de rendez-vous pour le moment.</p>';
}
async function loadQuotes(){
 const {data:rows,error}=await supabase.from('customer_quotes').select('id,user_id,service,description,status,created_at,amount').order('created_at',{ascending:false}).limit(100);
 if(error)throw error;const ids=[...new Set((rows||[]).map(x=>x.user_id).filter(Boolean))];let profiles={};
 if(ids.length){const p=await supabase.from('profiles').select('id,full_name,phone').in('id',ids);if(p.error)throw p.error;for(const x of p.data||[])profiles[x.id]=x;}
 $('quoteCount').textContent=`(${rows.length})`;
 $('quotesList').innerHTML=rows.length?rows.map(x=>{const p=profiles[x.user_id]||{};return `<article class="admin-card"><h3>${esc(x.service||'Demande de devis')}</h3><div class="admin-meta"><strong>Client :</strong> ${esc(p.full_name||'Nom non renseigné')}<br><strong>Téléphone :</strong> ${esc(p.phone||'Non renseigné')}<br><strong>Description :</strong> ${esc(x.description||'Aucune description')}<br><strong>Reçu le :</strong> ${dateLabel(x.created_at)}<br><strong>Montant :</strong> ${x.amount==null?'À définir':esc(x.amount)+' €'}</div><span class="admin-status">${esc(x.status||'En attente')}</span><div class="admin-actions">${selectStatus(x.id,x.status||quoteStatuses[0],quoteStatuses)}<button class="button primary" data-save-quote="${esc(x.id)}" type="button">ENREGISTRER</button></div></article>`}).join(''):'<p class="admin-empty">Aucune demande de devis pour le moment.</p>';
}
async function refresh(){message('Chargement des demandes…');try{await Promise.all([loadAppointments(),loadQuotes()]);message('Demandes actualisées.','ok');}catch(e){console.error(e);message(`Impossible de charger les demandes : ${e.message||e}. Vérifie que le script SQL V15 a bien été exécuté.`, 'error');}}
async function init(){const {data:{session},error}=await supabase.auth.getSession();if(error||!session){message('Connecte-toi d’abord avec ton compte administrateur DARKBYTE.','error');return;}if(session.user.app_metadata?.role!=='admin'){message('Accès refusé : ce compte n’a pas le rôle administrateur. Utilise le compte DARKBYTE autorisé dans Supabase.','error');return;}app.hidden=false;message(`Connecté en tant qu’administrateur : ${session.user.email||''}`);await refresh();}
document.querySelectorAll('.admin-tab').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.admin-tab').forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.admin-panel').forEach(x=>x.classList.toggle('active',x.id===`panel-${b.dataset.tab}`));}));
$('refreshButton').addEventListener('click',refresh);
$('logoutButton').addEventListener('click',async()=>{await supabase.auth.signOut();location.href='auth.html';});
document.addEventListener('click',async e=>{const a=e.target.closest('[data-save-appointment]'),q=e.target.closest('[data-save-quote]');if(!a&&!q)return;const isA=!!a,id=(a||q).dataset[isA?'saveAppointment':'saveQuote'];const select=document.querySelector(`[data-status-for="${CSS.escape(id)}"]`);if(!select)return;const button=a||q;button.disabled=true;button.textContent='ENREGISTREMENT…';try{const table=isA?'customer_appointments':'customer_quotes';const {error}=await supabase.from(table).update({status:select.value}).eq('id',id);if(error)throw error;await refresh();message('Statut enregistré avec succès.','ok');}catch(err){console.error(err);message(`Enregistrement impossible : ${err.message||err}`,'error');}finally{button.disabled=false;button.textContent='ENREGISTRER';}});
init();
