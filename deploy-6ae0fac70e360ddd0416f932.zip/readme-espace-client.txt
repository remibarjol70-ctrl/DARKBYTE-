DARKBYTE — AJOUT DE L'ESPACE CLIENT (SUPABASE)

CE QUE CONTIENT CE DOSSIER
- auth.html : page d'inscription / connexion / mot de passe oublié / espace client.
- auth.js : authentification réelle via Supabase Auth.
- supabase-config.js : emplacement de l'URL et de la clé publique Supabase.
- supabase-schema.sql : table de profil et règles de sécurité (RLS).
- index.html et rendez-vous.html : liens vers l'espace client ajoutés au menu.

IMPORTANT : l'espace client n'est PAS activé tant que Supabase n'est pas configuré.
Il ne faut pas publier en prétendant que les comptes fonctionnent avant d'avoir fait les étapes ci-dessous.

ÉTAPES DE CONFIGURATION
1. Crée un compte sur https://supabase.com/ puis crée un nouveau projet (formule gratuite pour commencer).
2. Dans le tableau de bord Supabase, ouvre Project Settings > API (ou Data API / API Keys selon l'interface).
3. Copie l'URL du projet et la clé publique anon / publishable.
4. Ouvre supabase-config.js et remplace :
   - https://VOTRE-PROJET.supabase.co par l'URL réelle du projet ;
   - VOTRE_CLE_ANON_OU_PUBLISHABLE par la clé publique.
5. NE JAMAIS mettre la clé secrète service_role dans un fichier du site. La clé publique anon/publishable est faite pour le navigateur, à condition de garder les règles RLS activées.
6. Dans Supabase > SQL Editor, crée une requête, colle le contenu de supabase-schema.sql et exécute-la.
7. Dans Supabase > Authentication > URL Configuration :
   - Site URL : l'URL publique exacte de ton site Netlify ;
   - Redirect URLs : ajoute https://TON-SITE.netlify.app/auth.html (remplace par ton vrai domaine).
8. Dans Authentication > Providers > Email, laisse le fournisseur Email activé. La confirmation par e-mail peut être activée ; dans ce cas, le client devra cliquer sur le lien reçu avant de pouvoir se connecter.
9. Redéploie le dossier complet DARKBYTE_site sur Netlify (pas uniquement auth.html).
10. Teste avec une adresse e-mail à toi : création de compte, réception/confirmation, connexion, déconnexion et mot de passe oublié.

LIMITES ACTUELLES
- Cette première version permet l'inscription, la connexion, la déconnexion et la réinitialisation du mot de passe après configuration Supabase.
- Le profil client est créé dans la table profiles, avec des règles RLS pour que chaque client ne puisse lire que son propre profil.
- Les devis et demandes de rendez-vous ne sont PAS encore enregistrés dans l'espace client. Les formulaires actuels restent indépendants (FormSubmit dans cette version). Il faudra ensuite les relier à une base de données avec des règles RLS avant d'afficher un historique client.
- Ne jamais demander ni stocker de mot de passe en clair dans une table personnalisée : Supabase Auth gère les mots de passe.
- La clé publique Supabase peut apparaître côté navigateur ; la clé secrète service_role ne doit jamais être publiée.

Si l'adresse de confirmation ou le site est inaccessible, vérifie les Redirect URLs et le domaine Netlify configuré dans Supabase.


ESPACE PERSONNEL V8
Rubriques ajoutées : vue d'ensemble, mes informations (nom/téléphone), mon panier, mes achats, mes devis et mes rendez-vous. Le tableau de bord est relié en lecture aux tables Supabase prévues.
IMPORTANT : le panier affiché est local au navigateur et n'est pas encore un vrai panier marchand. Les formulaires de devis et rendez-vous ne créent pas encore de lignes dans les historiques ; les achats nécessitent la future connexion du paiement. Le SQL prépare les tables et politiques RLS, mais il faut l'exécuter dans Supabase et configurer les clés avant déploiement.
