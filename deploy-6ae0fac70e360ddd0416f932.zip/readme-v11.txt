DARKBYTE v11 — correction du champ de rendez-vous

- Le formulaire de demande utilise désormais le nom appointment_date pour la date souhaitée.
- L’espace client lit et affiche customer_appointments.appointment_date.
- Le fichier de schéma fourni est aligné sur appointment_date à titre de référence.
- Aucun nouveau SQL n’est à exécuter pour cette correction.

Note : le formulaire de rendez-vous actuel envoie encore sa demande par e-mail (FormSubmit) ; cette correction de nom de champ ne crée pas à elle seule l’enregistrement automatique dans Supabase.
