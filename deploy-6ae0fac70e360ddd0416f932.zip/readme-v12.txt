DARKBYTE V12 — formulaire de rendez-vous Netlify Forms

Changement : le formulaire de rendez-vous n’utilise plus FormSubmit. Il est envoyé en arrière-plan à Netlify Forms, sans redirection vers une page tierce. Le champ de date reste appointment_date.

IMPORTANT APRÈS DÉPLOIEMENT :
1. Déployer le contenu du dossier DARKBYTE_site sur le site Netlify.
2. Dans Netlify, ouvrir Forms et vérifier que le formulaire « darkbyte-rendez-vous » est détecté après le déploiement.
3. Dans les paramètres du formulaire / notifications, ajouter l’adresse de réception remibarjol6@gmail.com si Netlify ne l’a pas déjà configurée.
4. Faire un test avec une adresse e-mail de test.

La confirmation affichée au client signifie que Netlify a accepté la soumission HTTP ; elle ne signifie pas qu’un rendez-vous est confirmé. DARKBYTE doit toujours confirmer le créneau.
Le formulaire de devis de la page d’accueil utilise encore son mécanisme existant : cette version ne le modifie pas.
