DARKBYTE V13 — FORMULAIRES NETLIFY

Cette version remplace FormSubmit sur le formulaire de devis. Les formulaires de devis et de rendez-vous sont tous deux déclarés avec data-netlify="true" et envoyés en arrière-plan à Netlify Forms.

Après déploiement :
1. Dans Netlify > Forms, vérifier la détection de « darkbyte-devis » et « darkbyte-rendez-vous ».
2. Dans les notifications de soumissions, créer une notification e-mail pour « Toute forme » ou une notification distincte pour chacun des deux formulaires, vers l'adresse de réception souhaitée.
3. Envoyer un test et vérifier que chaque soumission apparaît dans Netlify. Les notifications e-mail sont indépendantes de l'enregistrement des soumissions.

La confirmation à l'écran indique que Netlify a accepté la soumission HTTP ; elle ne confirme pas un devis ni un rendez-vous. Les demandes restent à traiter et à confirmer par DARKBYTE.
