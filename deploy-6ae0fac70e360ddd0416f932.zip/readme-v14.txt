DARKBYTE V14 — COMPTES CLIENTS OBLIGATOIRES

Les formulaires de devis et de rendez-vous exigent une session Supabase active. Chaque demande est enregistrée dans la table correspondante avec user_id = utilisateur connecté. L'e-mail Netlify continue d'être envoyé après l'enregistrement Supabase.

IMPORTANT : avant le déploiement, exécuter supabase-v14-policies.sql dans Supabase > SQL Editor. Il ajoute les politiques INSERT réservées aux utilisateurs authentifiés et ne supprime aucune donnée.

Tester sur un compte client : inscription/confirmation e-mail, connexion, demande de devis, demande de rendez-vous, puis vérifier les deux historiques dans l'espace client. Tester aussi en étant déconnecté : les demandes doivent être bloquées et proposer la connexion.

Les rendez-vous et devis sont enregistrés avec le statut initial « En attente » / « En attente de confirmation ». La validation ou le refus par l'administrateur n'est pas encore automatisé. Ne pas annoncer une réservation confirmée automatiquement.
