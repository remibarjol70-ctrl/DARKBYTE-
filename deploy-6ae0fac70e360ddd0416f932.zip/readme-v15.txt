DARKBYTE V15 — ADMINISTRATION DES RENDEZ-VOUS ET DEVIS

NOUVEAUTÉS
- Nouvelle page admin.html (à garder privée, l'accès est protégé par Supabase).
- L'administrateur peut consulter les rendez-vous et devis, puis changer leur statut.
- Les statuts modifiés sont enregistrés dans Supabase et s'affichent dans l'espace client après actualisation.
- La sécurité repose sur app_metadata.role = admin, jamais sur user_metadata ni sur une adresse e-mail déclarée dans le navigateur.

ÉTAPES OBLIGATOIRES AVANT UTILISATION
1. Dans Supabase > SQL Editor, exécuter le fichier supabase-v15-admin.sql.
2. Dans Supabase > Authentication > Users, créer d'abord le compte darkbyte.contact@gmail.com (ou vérifier qu'il existe déjà).
3. Ouvrir la fiche de cet utilisateur et modifier les métadonnées administrateur (app_metadata) pour y ajouter : {"role":"admin"}. Ne pas mettre ce rôle dans User Metadata / raw_user_meta_data.
   Selon l'interface Supabase, l'édition des app_metadata peut être proposée dans la fiche utilisateur. Si le champ n'est pas éditable, utiliser une méthode serveur sécurisée / Supabase Management API; ne jamais mettre une clé service_role dans le site.
4. Déconnecter puis reconnecter le compte darkbyte.contact@gmail.com afin de renouveler le jeton.
5. Déployer le contenu de ce dossier sur Netlify.
6. Ouvrir /admin.html et tester avec le compte administrateur.

STATUTS RENDEZ-VOUS : En attente de confirmation, Confirmé, Refusé, Terminé.
STATUTS DEVIS : En attente, En cours de traitement, Devis envoyé, Accepté, Refusé, Terminé.

IMPORTANT
- Les clients voient leurs propres demandes et statuts dans auth.html. Ils doivent actualiser leur espace pour voir un changement.
- Les clients ne peuvent pas changer eux-mêmes le statut grâce aux politiques RLS.
- Les demandes de rendez-vous et devis existantes ne sont pas supprimées.
- La V15 ne met pas en place l'envoi automatique d'un e-mail au client lors d'un changement de statut.
- Ne jamais publier de clé service_role / secret dans un fichier du site.

ATTRIBUER LE RÔLE ADMIN PAR SQL (après création/confirmation du compte)
Dans Supabase > SQL Editor, exécuter cette commande en remplaçant l'adresse uniquement si tu as choisi une autre adresse :
UPDATE auth.users
SET raw_app_meta_data = COALESCE(raw_app_meta_data, '{}'::jsonb) || '{"role":"admin"}'::jsonb
WHERE email = 'darkbyte.contact@gmail.com';
La commande doit affecter 1 ligne. Ensuite, déconnecte-toi et reconnecte-toi sur le site pour renouveler la session.
