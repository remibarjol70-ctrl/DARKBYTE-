DARKBYTE — VERSION DEMANDE DE DEVIS + RENDEZ-VOUS (PRÉ-LANCEMENT)

CONTENU
- index.html : accueil, services, catégories d’accessoires, estimateur de devis, formulaire de demande.
- rendez-vous.html : page de demande de rendez-vous en présentiel à Lacoste ou à distance.
- mentions-legales.html, confidentialite.html, cgv.html : documents modèles à compléter et faire vérifier.
- darkbyte-mark.svg : logo fourni dans la version précédente du site, affiché en haut à gauche et dans le pied de page.
- styles.css / script.js : affichage responsive, calcul local du devis et interactions.

FORMULAIRES E-MAIL
Les deux formulaires sont préparés avec FormSubmit (https://formsubmit.co/) pour transmettre les demandes à remibarjol6@gmail.com. Lors de la première soumission, FormSubmit envoie un e-mail d’activation à cette adresse : il faut cliquer sur le lien de confirmation. Tant que cette étape n’est pas faite, l’envoi automatique n’est pas actif. Le service est tiers : vérifier ses conditions, sa politique de confidentialité et l’information à donner aux visiteurs avant publication.
Le devis calculé est indicatif et son détail est ajouté au message envoyé.

RENDEZ-VOUS : LIMITE IMPORTANTE
La page recueille une date et une heure souhaitées, mais elle ne consulte pas un agenda partagé et ne bloque pas automatiquement les créneaux. Aucune disponibilité réelle ne peut être détectée avec un simple site statique. Pour le faire, il faut connecter un agenda / outil de réservation (par exemple Google Calendar appointment schedule ou Cal.com) ou développer un backend avec base de données, règles de durée et gestion des conflits. Jusqu’à cette connexion, le formulaire doit être présenté comme une DEMANDE et non une réservation confirmée. DARKBYTE doit confirmer manuellement chaque créneau.
La durée de réparation n’est pas calculable automatiquement à partir du seul motif : elle dépend du diagnostic, du modèle, des pièces et des tests. La page demande donc des informations et laisse DARKBYTE confirmer une estimation.

ADRESSE ET CONFIDENTIALITÉ
Le site affiche uniquement Lacoste (84480) et précise que l’accueil est sur rendez-vous. L’adresse résidentielle détaillée « résidence / logement » n’est pas publiée publiquement afin de protéger la vie privée et la sécurité. Elle peut être communiquée individuellement après confirmation du rendez-vous. Vérifier également l’autorisation d’exercer/recevoir des clients au domicile (bail, copropriété, assurance, règles locales et formalités applicables).

COLIS
Le texte indique que les frais de retour du matériel sont pris en charge ou remboursés selon les modalités convenues au devis. Il faut fixer précisément les conditions (plafond, transporteur, preuve de paiement, cas exclus) avant de promettre une prise en charge inconditionnelle.

À TERMINER AVANT LANCEMENT
1. Activer FormSubmit en cliquant le lien reçu par e-mail, puis tester depuis une autre adresse.
2. Connecter un vrai agenda/réservation pour détecter les créneaux libres et empêcher les doubles réservations.
3. Définir les jours/heures d’accueil, la durée des rendez-vous, délais de réparation et règles d’annulation.
4. Confirmer les modalités de remboursement des frais de retour colis.
5. Compléter les mentions légales avec identité juridique, SIRET, adresse professionnelle applicable, hébergeur et coordonnées.
6. Compléter CGV, politique de confidentialité, médiateur de la consommation, garanties, rétractation et formulaire type selon l’activité réelle.
7. Finaliser les conditions de réception du public à domicile et l’assurance.
8. Choisir les fournisseurs, produits, photos autorisées, prix d’achat, prix de vente, livraison et stock.
9. Créer et connecter un compte professionnel de paiement avant toute vente en ligne.
10. Tester le site, les formulaires, les liens et le parcours complet sur mobile et ordinateur.

IMPORTANT
Cette archive est un site de pré-lancement. Elle ne crée pas l’entreprise, ne confirme aucun rendez-vous automatiquement, n’encaisse aucun paiement et ne remplace pas les vérifications juridiques. Ne présente pas les créneaux comme disponibles tant qu’un agenda réel n’est pas connecté.
