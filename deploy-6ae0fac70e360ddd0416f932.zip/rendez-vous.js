import { supabase } from './supabase-client.js';
const form=document.getElementById('bookingForm');
if(form){
 const button=document.getElementById('bookingSubmit'),status=document.getElementById('bookingStatus');
 form.addEventListener('submit',async e=>{
  e.preventDefault();if(!form.reportValidity())return;
  const {data:{session},error:sessionError}=await supabase.auth.getSession();
  if(sessionError||!session){status.innerHTML='Pour demander un rendez-vous, <a href="auth.html?redirect=rendez-vous.html">connecte-toi ou crée ton compte client</a>.';return;}
  const fd=new FormData(form),date=fd.get('appointment_date'),time=fd.get('Heure souhaitée');
  const appointmentDate=new Date(`${date}T${time}`).toISOString();
  const service=String(fd.get('Motif')||'Rendez-vous');
  const description=[fd.get('Description'),fd.get('Modalité'),fd.get('Durée ou contraintes')].filter(Boolean).join(' — ');
  const original=button.innerHTML;button.disabled=true;button.textContent='Enregistrement…';status.textContent='Enregistrement sécurisé de ta demande…';
  try{
   const {error}=await supabase.from('customer_appointments').insert({user_id:session.user.id,appointment_date:appointmentDate,service,status:'En attente de confirmation'});
   if(error)throw error;
   fd.set('Client connecté',session.user.email||'');
   const response=await fetch('/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(fd).toString()});
   if(!response.ok)throw new Error('Netlify notification failed');
   form.reset();status.textContent='Ta demande est enregistrée dans ton espace client et transmise à DARKBYTE. Le créneau sera confirmé après vérification.';status.style.color='var(--cyan)';
  }catch(err){console.error(err);status.textContent='La demande n’a pas pu être finalisée. Vérifie ton espace client avant de réessayer, ou contacte DARKBYTE.';status.style.color='';}
  finally{button.disabled=false;button.innerHTML=original;}
 });
}
