// DARKBYTE — estimateur local et préparation d'une demande e-mail (aucun paiement actif)
const DARKBYTE_EMAIL = "remibarjol6@gmail.com";
const year = document.getElementById("year");
if (year) year.textContent = new Date().getFullYear();
const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("mainNav");
if (menuToggle && nav) {
  menuToggle.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(isOpen));
  });
  nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("open"); menuToggle.setAttribute("aria-expanded", "false");
  }));
}
const checks = [...document.querySelectorAll(".option-row input")];
const totalEl = document.getElementById("quoteTotal");
const summaryEl = document.getElementById("quoteSummary");
const estimateInput = document.getElementById("selectedEstimate");
const productInput = document.getElementById("selectedProduct");
const serviceSelect = document.querySelector('[name="service"]');
function selectedServices() { return checks.filter(c => c.checked); }
function updateQuote() {
  const selected = selectedServices();
  const total = selected.reduce((sum, c) => sum + Number(c.dataset.price || 0), 0);
  if (totalEl) totalEl.textContent = total.toLocaleString("fr-FR", {style:"currency", currency:"EUR"});
  if (summaryEl) summaryEl.textContent = selected.length ? selected.map(c => c.dataset.label).join(" • ") : "Aucune prestation sélectionnée.";
  if (estimateInput) estimateInput.value = selected.length ? total.toLocaleString("fr-FR", {style:"currency", currency:"EUR"}) + " — estimation indicative" : "Aucune estimation sélectionnée";
}
checks.forEach(c => c.addEventListener("change", updateQuote));
updateQuote();
document.querySelectorAll("[data-product]").forEach(a => a.addEventListener("click", () => {
  if (productInput) productInput.value = a.dataset.product;
  if (serviceSelect) serviceSelect.value = "Achat accessoire gaming";
}));
// Les demandes de devis exigent un compte client connecté.
import('./supabase-client.js').then(({supabase})=>{
 const quoteForm=document.getElementById('quoteForm');
 if(!quoteForm)return;
 quoteForm.addEventListener('submit',async(event)=>{
  event.preventDefault();
  if(!quoteForm.reportValidity())return;
  const hint=document.getElementById('formHint');
  const button=quoteForm.querySelector('button[type="submit"]');
  const original=button?.innerHTML||'';
  const {data:{session},error:sessionError}=await supabase.auth.getSession();
  if(sessionError||!session){if(hint)hint.innerHTML='Pour envoyer un devis, <a href="auth.html?redirect=index.html#devis">connecte-toi ou crée ton compte client</a>.';return;}
  const selected=selectedServices();
  const total=selected.reduce((sum,c)=>sum+Number(c.dataset.price||0),0);
  const service=serviceSelect?.value||'Demande de devis';
  const description=[document.querySelector('[name="product"]')?.value,document.querySelector('[name="message"]')?.value,selected.map(c=>c.dataset.label).join(', '),document.querySelector('[name="estimate"]')?.value].filter(Boolean).join(' — ');
  if(button){button.disabled=true;button.textContent='Enregistrement…';}
  if(hint)hint.textContent='Enregistrement sécurisé de ta demande…';
  try{
   const {error}=await supabase.from('customer_quotes').insert({user_id:session.user.id,service,description,amount:total||null,status:'En attente'});
   if(error)throw error;
   const hidden=(name,value)=>{let el=quoteForm.querySelector(`[name="${name}"]`);if(!el){el=document.createElement('input');el.type='hidden';el.name=name;quoteForm.appendChild(el);}el.value=value;};
   hidden('form-name','darkbyte-devis');hidden('Client connecté',session.user.email||'');
   const response=await fetch('/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(quoteForm)).toString()});
   if(!response.ok)throw new Error('Netlify notification failed');
   quoteForm.reset();updateQuote();
   if(hint)hint.textContent='Ta demande est enregistrée dans ton espace client et transmise à DARKBYTE. Elle reste en attente de validation.';
  }catch(err){console.error(err);if(hint)hint.textContent='La demande n’a pas pu être finalisée. Réessaie ou contacte DARKBYTE. Si elle apparaît déjà dans ton espace client, ne la renvoie pas.';}
  finally{if(button){button.disabled=false;button.innerHTML=original;}}
 });
});
