// Configuration Supabase DARKBYTE
// La clé publishable est destinée au navigateur. Ne jamais ajouter de clé secrète/service_role.
export const SUPABASE_URL = 'https://yzqzbowlyizvcfsqbzuz.supabase.co';
export const SUPABASE_ANON_KEY = 'sb_publishable_3T5QlVZxDTNWpia2QyeC7Q_FPIZl9o6';
