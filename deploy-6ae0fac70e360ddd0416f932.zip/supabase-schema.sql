-- DARKBYTE : tables de l'espace client. À exécuter dans Supabase > SQL Editor.
create table if not exists public.profiles(id uuid primary key references auth.users(id) on delete cascade,full_name text,phone text,created_at timestamptz not null default now(),updated_at timestamptz not null default now());
alter table public.profiles add column if not exists phone text;
alter table public.profiles enable row level security;
drop policy if exists "Clients can read their own profile" on public.profiles;
create policy "Clients can read their own profile" on public.profiles for select to authenticated using(auth.uid()=id);
drop policy if exists "Clients can insert their own profile" on public.profiles;
create policy "Clients can insert their own profile" on public.profiles for insert to authenticated with check(auth.uid()=id);
drop policy if exists "Clients can update their own profile" on public.profiles;
create policy "Clients can update their own profile" on public.profiles for update to authenticated using(auth.uid()=id) with check(auth.uid()=id);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path='' as $$ begin insert into public.profiles(id,full_name) values(new.id,new.raw_user_meta_data->>'full_name') on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
create table if not exists public.customer_quotes(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,service text not null,description text,status text not null default 'En attente',created_at timestamptz not null default now());
create table if not exists public.customer_appointments(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,appointment_date timestamptz not null,service text,status text not null default 'En attente de confirmation',created_at timestamptz not null default now());
create table if not exists public.customer_orders(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,order_number text unique,status text not null default 'En attente',total_amount numeric(10,2),currency text not null default 'EUR',created_at timestamptz not null default now());
alter table public.customer_quotes enable row level security; alter table public.customer_appointments enable row level security; alter table public.customer_orders enable row level security;
drop policy if exists "Clients read own quotes" on public.customer_quotes; create policy "Clients read own quotes" on public.customer_quotes for select to authenticated using(auth.uid()=user_id);
drop policy if exists "Clients read own appointments" on public.customer_appointments; create policy "Clients read own appointments" on public.customer_appointments for select to authenticated using(auth.uid()=user_id);
drop policy if exists "Clients read own orders" on public.customer_orders; create policy "Clients read own orders" on public.customer_orders for select to authenticated using(auth.uid()=user_id);
-- Devis, rendez-vous et commandes seront créés par des fonctions serveur sécurisées après connexion des formulaires/paiement.
-- Ne jamais publier une clé Supabase service_role dans le code du site.
