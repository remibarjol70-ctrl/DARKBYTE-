-- DARKBYTE V14 : autoriser un client authentifié à créer SES demandes uniquement.
-- À exécuter une seule fois dans Supabase SQL Editor. Ne supprime aucune donnée.
DROP POLICY IF EXISTS "Clients create own quotes" ON public.customer_quotes;
CREATE POLICY "Clients create own quotes" ON public.customer_quotes
FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Clients create own appointments" ON public.customer_appointments;
CREATE POLICY "Clients create own appointments" ON public.customer_appointments
FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
