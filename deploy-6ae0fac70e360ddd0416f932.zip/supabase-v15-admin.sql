-- DARKBYTE V15 — accès administrateur sécurisé via app_metadata.role
-- À exécuter une seule fois dans Supabase > SQL Editor.
-- L'administrateur doit être défini dans Auth > Users > son utilisateur > app_metadata.

-- Profils : permettre à l'administrateur de lire les coordonnées utiles aux demandes.
DROP POLICY IF EXISTS "Admin read all profiles" ON public.profiles;
CREATE POLICY "Admin read all profiles" ON public.profiles
FOR SELECT TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Rendez-vous : lecture globale et modification du statut réservées à l'administrateur.
DROP POLICY IF EXISTS "Admin read all appointments" ON public.customer_appointments;
CREATE POLICY "Admin read all appointments" ON public.customer_appointments
FOR SELECT TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

DROP POLICY IF EXISTS "Admin update appointments" ON public.customer_appointments;
CREATE POLICY "Admin update appointments" ON public.customer_appointments
FOR UPDATE TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Devis : lecture globale et modification du statut réservées à l'administrateur.
DROP POLICY IF EXISTS "Admin read all quotes" ON public.customer_quotes;
CREATE POLICY "Admin read all quotes" ON public.customer_quotes
FOR SELECT TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

DROP POLICY IF EXISTS "Admin update quotes" ON public.customer_quotes;
CREATE POLICY "Admin update quotes" ON public.customer_quotes
FOR UPDATE TO authenticated
USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');
